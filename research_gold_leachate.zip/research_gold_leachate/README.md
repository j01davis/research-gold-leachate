# Environmentally friendly gold leaching reagents — 环保提金剂

**Open [`index.html`](index.html) in any browser.** Fully offline — copy this folder to a USB stick
and every page, image and document opens with no network connection. 2.3 MB.

Nine Chinese brands, each covering all six sections you asked for, plus the cross-brand comparison
tables you specifically required.

## The two brands you asked about

| Brand | Manufacturer | Position |
|---|---|---|
| **金蝉 — Jinchan** ("Golden Cicada") | 广西森合高新科技股份有限公司 Guangxi Senhe High-Tech (listed company) | Market leader; by far the best-documented reagent in this class |
| **东北虎 — Dongbeihu** ("Northeast Tiger") | 广西地生金化工有限公司 Guangxi Disheng Jin Chemical | Named in the GOLD review as a market participant, but no performance data published |

Both are covered in full, alongside seven competitors.

## The finding that matters most

**These reagents are not actually cyanide-free**, despite every vendor marketing them as 无氰
("cyanide-free"). The peer-reviewed review this collection is built on states that they are
*synthesised from ferrocyanide (黄血盐) with urea and caustic soda by high-temperature reaction*, and
that **standard free-CN⁻ test methods can detect "cyano groups" in their solutions**.

They are accurately described as **low-toxicity complexed-cyanide reagents**. The toxicity gap is
real and large — under **GBZ 230-2010**, NaCN is Class I extremely hazardous (oral LD50 **6.4
mg/kg**) while these are Class III (>500 mg/kg) or Class IV (>5,000 mg/kg), a 78–780× difference.
And the tailings benefit is genuine: one documented comparison showed NaCN leachate at **210 mg/L**
cyanide versus Jinchan at **<0.004 mg/L**.

**But do not rely on the "cyanide-free" label for permitting or export.** If your regulator runs a
total or free cyanide test, these can register a reading. Get the SDS, the UN transport
classification and an independent assay first. Full detail, with the Chinese source text, is on the
index page.

## What the comparison actually shows

**Performance.** Across **15 documented head-to-head tests**, these reagents land between **−0.5 and
+3.2 percentage points** of sodium cyanide, median about **+1 pp**. Several achieve it faster (24 h
vs 36 h). Nobody shows a step change. *The case for switching is environmental and operational, not
metallurgical* — which is the opposite of how it is marketed.

**Evidence, not chemistry, is the discriminator.** All nine brands use the same synthesis family, so
nothing differentiates them technically. What differentiates them is how much they have proven:

| Has published industrial-scale results | Published nothing |
|---|---|
| 金蝉 Jinchan (8 studies, 3 countries) · 敏杰 Minjie (2 industrial trials) · 绿金 Lvjin · CG505 | 东北虎 Dongbeihu · 王牌 Wangpai · 金斧 Jinfu · 金虎 Jinhu |

**Dosage varies 60×, so never compare reagent price per tonne.** Jinchan and CNLITE run 0.3–0.6
kg/t. Sandioss runs 20 kg/t plus 20 kg/t of aid — but it is a refractory-residue reagent for 70 g/t
feed, so that is not a fault. Compare **cost per tonne of ore**, within the same duty.

**Two brands cost you capital; seven do not.** CG505 needs a tailings dosing/mixing stage, Sandioss
needs a 110 °C oven pre-treatment. Everything else drops into an existing CIP/CIL/heap circuit
unchanged.

## Pricing reality

| Brand | Price | Quality of the figure |
|---|---|---|
| **CNLITE** | US$2.20–3.00/kg (US$2,200/t at ≥1 t) | Best $ data — but **marketplace listings, not an official factory list** |
| **金蝉 Jinchan** | ¥8,000–16,000/t domestic (≈US$1,100–2,200/t) | Back-calculated from 25 kg pack listings; Senhe's own export pages show price *"Not informed"* |
| **金虎 Jinhu** | ¥18,500/t | Single B2B listing, unverified |
| Unbranded cross-check | US$1.80–2.60/kg at 100 kg MOQ; US$2,289–2,359/t at 1 t MOQ | Confirms the band |
| **NaCN benchmark** | US$4,300–7,000/t | Plus HW33 hazardous-waste cost and ¥1,000/t environmental tax |
| 东北虎, 敏杰, CG505, 绿金, 圣的 | **no price found anywhere** | — |

**No manufacturer in this market publishes a real price list.** Everything above is a reseller or
marketplace figure. On export terms the whole class converges on roughly **US$1–2 per tonne of
ore**, against US$2.50–5.00/t for cyanide — my arithmetic on published dosages, not a quote.

The one figure that came from an actual industrial cost comparison is **Minjie at −¥1.75 per tonne
of ore** versus NaCN, with leach time cut 25%. It lands in the same ballpark, which is the best check
available that the arithmetic is right.

## Production equipment (your section 6)

All of these reagents are made the same way. Four raw-material routes are documented with full
patent composition ranges, including **route C, which is genuinely free of cyanide complexes** —
specify that one if you need a reagent that passes a cyanide test cleanly.

| Parameter | Value |
|---|---|
| Equipment | **Rotary kiln** or **electric roasting furnace**, plus mill, blender, bagging line |
| Temperature | **600–900 °C** typical (patent range 450–1,000 °C) |
| Hold time | **1–6 h** (one patent 5–15 min) |
| Atmosphere | Air in most cases; oxygen-enriched rare |
| Product | White/off-white solid, **25 kg bags** standard |

Note that a 900 °C duty needs a proper metallurgical kiln — small electric roasting furnaces for
powder materials top out around 650 °C.

## Buying advice, if you want the short version

- **Reachable from outside China:** CNLITE (established distributors in Zimbabwe and South Africa,
  best price data) and Jinchan (Senhe's own English export storefronts, but no published price and
  marked an *unverified company* on one platform).
- **Best technical credibility** for a regulator or JV partner: **Jinchan or Minjie** — you can hand
  over peer-reviewed industrial trial papers.
- **Best third-party documentation:** **绿金 Lvjin** — Shanghai Hazardous Chemicals Centre classified
  it **ordinary goods** (ships by road, rail, sea, air) and Henan CDC assessed its toxicity as
  *equivalent to caustic soda*. That transport classification avoids dangerous-goods freight,
  licensing and storage bunding, which at a remote site often exceeds the reagent cost.
- **If tailings cyanide is your problem,** CG505 is the only two-part system that treats the waste
  stream: filtrate cyanide 244.25 → **0.18 mg/L**.
- **Always request the TDS and SDS in writing.** A buyer enquiry from April 2026 shows these are not
  published and must be asked for.

## Layout

```
research_gold_leachate/
  index.html          start here — the cyanide finding, all six
                      comparison tables, production equipment
  README.md           this file
  01_jinchan/         金蝉 — market leader, most documented
  02_dongbeihu/       东北虎 — named in the review, no data
  03_cnlite/          CNLITE — strongest export channel
  04_minjie/          敏杰 — Guangxi Academy of Sciences
  05_cg505/           CG505 — two-part A+B system
  06_lvjin/           绿金 — best third-party documentation
  07_sandioss/        圣的 — refractory residues
  08_others/          金虎 · 王牌 · 金斧 and minor brands
  img/                journal page scans + product photo
  _docs/              the primary source PDF
```

## Primary source

[`_docs/2023_GOLD-journal_Review-of-new-eco-friendly-gold-leaching-reagents_CN.pdf`](_docs/2023_GOLD-journal_Review-of-new-eco-friendly-gold-leaching-reagents_CN.pdf)

崔铭耀, 李传明, 苏慧丽, 高文昊, 李晓畅, 吕宪俊 —《新型环保提金剂的研究及应用概况》, **黄金 (GOLD)**
2023, Vol. 44 No. 10, pp. 38–44, doi:10.11792/hj202310 09, 山东科技大学化学与生物工程学院 (Shandong
University of Science and Technology). 7 pages, Chinese.

This is the backbone of the collection — the brand list, the synthesis routes, the case studies and
the toxicity classification all come from here or from the primary studies it cites. Everything
labelled **peer-reviewed** in the HTML traces back to it; everything labelled **vendor** does not.

## Honest limitations

- **Four brands have no published performance data at all** — 东北虎 Dongbeihu, 王牌 Wangpai, 金斧 Jinfu and 89提金剂. The GOLD review names them as market
  participants and cites no case studies. Their pages say so plainly rather than filling the gap with
  marketing copy. **Insist on your own ore test work before committing to any of them.**
- **No manufacturer publishes a price.** Every price here is a reseller or B2B marketplace figure,
  and the CNLITE tier table — the best-looking price data in the collection — could not be traced to
  an official CNLITE source.
- **Corporate identity is unclear in two cases.** An Alibaba listing attributes CNLITE to *Shandong
  Xinhai Mining Technology* rather than Yantai CNLITE; and the relationship between 金虎-branded
  listings from Changsha Hongshun and from Daye Jinxin Environmental Technology is unexplained.
  Verify the legal entity before contracting.
- **No reagent-plant equipment costs exist publicly.** Section 6 gives synthesis routes, roasting
  conditions and equipment types, but no vendor publishes a capital cost for a reagent plant.
- **Vendor images are scarce.** Only one product photograph could be retrieved for this entire
  product class; Jinchan, Dongbeihu and Lvjin pages yielded no usable images. The remaining images
  are rendered pages of the source journal article, which at least let you read the Chinese original
  without a PDF reader.
- **ISO certification scope is unconfirmed.** CNLITE claims ISO 9001 and ISO 14001, but it is not
  stated whether the certificates cover this product.
- Figures were captured on the build date and will drift.
